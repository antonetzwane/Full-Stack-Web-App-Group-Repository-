-- CreateTable
CREATE TABLE "HealthCheck" (
    "id" SERIAL NOT NULL,
    "label" TEXT NOT NULL DEFAULT 'ok',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "HealthCheck_pkey" PRIMARY KEY ("id")
);

-- CreateTable User (use can be a student guest, student and a lecture)
CREATE TABLE "Users" (
    "userId" SERIAL NOT NULL,
    "name" name VARCHAR(100) NOT NULL,
    "email" name VARCHAR(150) UNIQUE,
    "role" VARCHAR(20) CHECK (role IN ('lecture', 'student', 'guest')), --This specifies that the user can be a lecture, guest or a student.
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    --created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    --Constraint?
);

-- CreateTable Poll
CREATE TABLE "Polls" (
    "pollId" SERIAL NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "description" TEXT,
    "createdby" INT REFERENCES Users(userId) ON DELETE CASCADE,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
   --TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable Vote
CREATE TABLE "Votes" (
    "voteId" SERIAL NOT NULL,
    "userId" INT REFERENCES Users(userId) ON DELETE CASCADE,
    "pollId" INT REFERENCES Polls(pollIdid) ON DELETE CASCADE, --options or poll table?
    "questionId" INT REFERENCES Questions(questionId) ON DELETE CASCADE,
    "answerText" TEXT,  --This is not limited, can be used for open ended answers.
    "votedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "anonymousKey" TEXT,
    UNIQUE(userId, questionId) -- this line/code prevents a student or guest from voting more that once or double voting.
);

-- CreateTable Question
CREATE TABLE "Questions" (
    "questionId" SERIAL NOT NULL,
    "pollId" INT REFERENCES Poll(pollId) ON DELETE CASCADE,
    "questionText" TEXT NOT NULL,,
    "questionType" VARCHAR(20) CHECK (questionType IN ('multiple_choice', 'open_ended'))
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
);

-- CreateTable Choice
CREATE TABLE "Choice" (
    "choiceId" SERIAL NOT NULL,
    "questionId" INT REFERENCES Questions(questionId) ON DELETE CASCADE,
    "choiceText" VARCHAR(200) NOT NULL,
);

